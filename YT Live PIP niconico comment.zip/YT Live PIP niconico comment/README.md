# YT Live NicoNico Comment Overlay

A **Chrome Extension (Manifest V3)** that overlays YouTube Live chat comments directly on top of the video player in **NicoNico Douga style** — scrolling right-to-left — including full **Picture-in-Picture** support.

---

## Features

| Feature | Details |
|---|---|
| NicoNico-style comments | Right-to-left scrolling on a Canvas overlay |
| Super Chat detection | Detected via `yt-live-chat-paid-message-renderer`; rendered with coloured badge & larger font |
| Membership messages | `yt-live-chat-membership-item-renderer`; rendered in green |
| PiP overlay | Canvas frames mirrored to a hidden video element via `captureStream()` |
| Performance | Max simultaneous comments limit; lane-based vertical slot allocation; `requestAnimationFrame` loop |
| Configurable | Popup with sliders for speed, font size, opacity, max comments |

---

## Project Structure

```
manifest.json
src/
  content.js      — Chat observer (iframe) + Canvas overlay (watch page)
  background.js   — Service worker; relays iframe→watch-page messages
  overlay.css     — Positions the overlay canvas
popup/
  popup.html      — Extension popup UI
  popup.css       — Dark glassmorphism styling
  popup.js        — Settings load/save + hot-reload
icons/
  icon16.png
  icon48.png
  icon128.png
scripts/
  generate_icons.js  — (Optional) re-generate icons with sharp
```

---

## Installation (Developer Mode)

1. Open **chrome://extensions**
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select this folder (`YT Live PIP niconico comment`)

---

## How It Works

### Chat extraction (iframe)
YouTube embeds the live chat as a separate `iframe` (`/live_chat?...`).  
The content script runs inside this iframe and sets up a `MutationObserver` on `#items.yt-live-chat-item-list-renderer`.  
Each new `yt-live-chat-*-renderer` element is parsed and its payload is sent via `chrome.runtime.sendMessage` → `background.js` → top-frame content script.

### Overlay rendering (watch page)
A `<canvas id="yt-nicovideo-canvas">` is injected as an absolutely-positioned child inside `#movie_player`, filling it 100 × 100 %.  
A `requestAnimationFrame` loop advances each comment's `x` coordinate leftward, draws it with a text-shadow for readability, and removes it once it exits the left edge.

### Vertical lane allocation
Comments are assigned to horizontal "lanes" (rows), preventing stacking.  
When all lanes are full the comment is assigned a random lane (wraps).

### PiP support
When `enterpictureinpicture` fires on the `<video>` element:
1. A second off-screen `<canvas>` (`pipCanvas`) is created.
2. Each render tick copies the main canvas into `pipCanvas`.
3. `pipCanvas.captureStream(30)` feeds a hidden `<video>` element.
4. That video calls `requestPictureInPicture()` to show the comment overlay in a floating PiP window alongside the main PiP video.

> **Note:** Browsers currently allow only one PiP window at a time. The overlay PiP replaces the video PiP. A truly simultaneous dual-PiP is a browser-level limitation. To keep both, keep the main video in the tab and use PiP only for the overlay.

---

## Settings (Popup)

| Setting | Range | Default |
|---|---|---|
| Speed | 2 – 20 px/frame | 8 |
| Font Size | 14 – 48 px | 26 px |
| Opacity | 10 – 100 % | 90 % |
| Max Comments | 5 – 80 | 40 |
| Show Super Chats | on/off | on |
| Show Memberships | on/off | on |

Settings are persisted in `chrome.storage.sync` and hot-reloaded into the running content script immediately on **Apply**.

---

## Permissions

| Permission | Reason |
|---|---|
| `storage` | Persist user settings via `chrome.storage.sync` |
| `host_permissions: youtube.com` | Inject content scripts & communicate across frames |

No network requests are made; all processing is local.
