/**
 * content.js
 *
 * [chat iframe]  MutationObserver でコメント検出 -> background.js 経由で中継
 * [watch page]   コメントを Canvas にニコニコ風スクロール描画
 *
 * PiP方式: Document PiP API でウィンドウを開き、
 *   Canvas に drawImage(video) でフレームをミラー + コメントを重ね描き。
 *   video 要素はメインDOMに残したまま -> 閉じても黒画面にならない。
 */

(function () {
  'use strict';

  const IS_CHAT  = location.href.includes('/live_chat');
  const IS_WATCH = location.href.includes('/watch');

  if (IS_CHAT)  { initChatObserver(); return; }
  if (IS_WATCH) { initOverlay(); }

  // YouTubeはSPA（単一ページアプリケーション）のため、ページ遷移を監視
  document.addEventListener('yt-navigate-finish', () => {
    if (location.href.includes('/watch') && !renderer) {
      initOverlay();
    }
  });

  /* ==============================================
   * CHAT IFRAME: コメント抽出 & 送信
   * ============================================== */
  function initChatObserver() {
    waitForElement('#items.yt-live-chat-item-list-renderer', (list) => {
      const seen = new Set();
      new MutationObserver((muts) => {
        for (const m of muts)
          for (const n of m.addedNodes)
            if (n.nodeType === Node.ELEMENT_NODE) parseItem(n, seen);
      }).observe(list, { childList: true });
    });
  }

  function parseItem(el, seen) {
    const tag = el.tagName.toLowerCase();
    const isSC  = tag === 'yt-live-chat-paid-message-renderer';
    const isMem = tag === 'yt-live-chat-membership-item-renderer';
    const isReg = tag === 'yt-live-chat-text-message-renderer';
    if (!isSC && !isMem && !isReg) return;

    const author = (el.querySelector('#author-name') || el.querySelector('#name'))
                     ?.textContent.trim() || '名無し';

    let text = '';
    const msgEl = el.querySelector('#message');
    if (msgEl) {
      for (const n of msgEl.childNodes)
        text += n.nodeType === Node.TEXT_NODE ? n.textContent
              : n.tagName  === 'IMG'          ? (n.alt || '')
              : n.textContent;
      text = text.trim();
    } else if (isMem) {
      text = (el.querySelector('#header-subtext, #detail-text'))
               ?.textContent.trim() || '[メンバー]';
    }

    let scAmount = '', scColor = '';
    if (isSC) {
      scAmount = el.querySelector('#purchase-amount, #purchase-amount-chip')
                   ?.textContent.trim() || '';
      const hdr = el.querySelector('#header');
      if (hdr) {
        const bg = getComputedStyle(hdr).backgroundColor;
        if (bg && bg !== 'rgba(0, 0, 0, 0)') scColor = bg;
      }
      // テキストがない（金額のみの）スーパーチャットも表示するため空文字を回避
      if (!text) text = scAmount ? `${scAmount} ナイスパ！` : 'ナイスパ！';
    }

    if (!text) return;

    const key = `${author}:${text}`;
    if (seen.has(key)) return;
    seen.add(key);
    if (seen.size > 500) seen.delete(seen.values().next().value);

    try {
      chrome.runtime.sendMessage({
        type: 'YT_CHAT_COMMENT',
        author, text, isSuperChat: isSC, isMembership: isMem,
        superChatAmount: scAmount, superChatColor: scColor,
      }, () => {
        // エラー（受信側がいない等）を無視してコンソールを汚さない
        if (chrome.runtime.lastError) {}
      });
    } catch (e) {}
  }

  /* ==============================================
   * WATCH PAGE: オーバーレイ初期化
   * ============================================== */
  let renderer      = null;
  let overlayEnabled = true;

  function initOverlay() {
    const DEFAULTS = {
      enabled: true, maxComments: 40, speed: 8,
      fontSize: 26, opacity: 0.9, showSuperChat: true, showMembership: true, showUsername: true,
    };
    chrome.storage.sync.get(DEFAULTS, (s) => {
      overlayEnabled = s.enabled;
      if (!overlayEnabled) return;
      waitForElement('#movie_player', () => {
        renderer = new CommentRenderer(s);
        renderer.mount();
        listenComments(s);
        // ポップアップ / background.js からの PiP 起動リクエストを受信
        document.addEventListener('__yt_nicovideo_pip_request', () => {
          renderer?.enableDocumentPiP();
        });
      });
    });

    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type === 'SETTINGS_UPDATE') {
        overlayEnabled = msg.settings.enabled !== false;
        renderer?.applySettings(msg.settings);
      }
    });
  }

  function listenComments(s) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.type !== 'YT_CHAT_COMMENT' || !overlayEnabled || !renderer) return;
      if (msg.isSuperChat  && s.showSuperChat  === false) return;
      if (msg.isMembership && s.showMembership === false) return;
      renderer.addComment(msg);
    });
  }

  /* ==============================================
   * CommentRenderer
   * ============================================== */
  class CommentRenderer {
    constructor(s) {
      this.maxComments = s.maxComments ?? 40;
      this.baseSpeed   = s.speed      ?? 8;
      this.fontSize    = s.fontSize   ?? 26;
      this.opacity     = s.opacity    ?? 0.9;
      this.showUsername= s.showUsername ?? true;

      this.comments  = [];
      this.canvas    = null;
      this.ctx       = null;
      this.playerEl  = null;
      this.overlayEl = null;
      this.raf       = null;
      this.resizeObs = null;

      // PiP
      this.pipWin    = null;
      this.pipCanvas = null;
      this.pipCtx    = null;
      this.pipVideo  = null;
    }

    /* -- Canvasをプレイヤーの上に配置 -- */
    mount() {
      this.playerEl = document.querySelector('#movie_player');
      if (!this.playerEl) return;

      this.overlayEl = document.createElement('div');
      this.overlayEl.id = 'yt-nicovideo-overlay-wrapper';
      this.overlayEl.setAttribute('aria-hidden', 'true');

      this.canvas = document.createElement('canvas');
      this.canvas.id = 'yt-nicovideo-canvas';
      this.overlayEl.appendChild(this.canvas);

      const vid = this.playerEl.querySelector('video');
      if (vid?.parentNode) vid.parentNode.insertBefore(this.overlayEl, vid.nextSibling);
      else this.playerEl.appendChild(this.overlayEl);

      this.ctx = this.canvas.getContext('2d');
      this.syncSize();

      this.resizeObs = new ResizeObserver(() => this.syncSize());
      this.resizeObs.observe(this.playerEl);

      this.injectPlayerButton();

      const tick = () => { this.render(); this.raf = requestAnimationFrame(tick); };
      this.raf = requestAnimationFrame(tick);
    }

    injectPlayerButton() {
      waitForElement('.ytp-right-controls', (controls) => {
        if (document.getElementById('yt-nicovideo-player-toggle')) return;
        const btn = document.createElement('button');
        btn.id = 'yt-nicovideo-player-toggle';
        btn.className = 'ytp-button';
        btn.style.width = 'auto';
        btn.style.padding = '0 8px';
        btn.style.verticalAlign = 'top';
        btn.innerHTML = `<svg width="100%" height="100%" viewBox="0 0 36 36"><text x="18" y="23" fill="#fff" font-size="11" text-anchor="middle" font-weight="bold">NICO</text></svg>`;
        btn.title = 'メイン画面のニコニココメント表示/非表示';
        btn.onclick = () => {
          if (this.overlayEl) {
            const isHidden = this.overlayEl.style.display === 'none';
            this.overlayEl.style.display = isHidden ? 'block' : 'none';
          }
        };
        // 最初の要素の前に挿入（字幕ボタンの左あたり）
        controls.insertBefore(btn, controls.firstChild);
      });
    }

    syncSize() {
      if (!this.playerEl || !this.canvas) return;
      const r = this.playerEl.getBoundingClientRect();
      this.canvas.width  = r.width  || 854;
      this.canvas.height = r.height || 480;
    }

    /* -- レンダリング: 位置更新 -> メインCanvas -> PiP Canvas -- */
    render() {
      // 1. 位置更新（1フレームに1回のみ）
      const dead = [];
      for (const c of this.comments) {
        c.x -= c.speed;
        if (c.x + c.width < 0) dead.push(c);
      }
      for (const c of dead) this.comments.splice(this.comments.indexOf(c), 1);

      // 2. メインCanvas
      if (this.ctx && this.canvas) {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        for (const c of this.comments) this.drawComment(this.ctx, c);
      }

      // 3. PiP Canvas（ビデオミラー + コメント）
      if (this.pipCtx && this.pipCanvas && this.pipVideo) {
        const pc = this.pipCtx, pv = this.pipCanvas;
        pc.clearRect(0, 0, pv.width, pv.height);
        try { pc.drawImage(this.pipVideo, 0, 0, pv.width, pv.height); } catch (_) {}
        for (const c of this.comments) this.drawComment(pc, c);
      }
    }

    drawComment(ctx, c) {
      ctx.save();
      ctx.globalAlpha  = this.opacity;
      ctx.textBaseline = 'top';
      ctx.font = `bold ${c.fontSize}px "Noto Sans JP","Helvetica Neue",Arial,sans-serif`;

      if (c.isSuperChat) {
        // 文字のみに色をつける
        ctx.fillStyle = c.superChatColor || '#f9a825';
      } else {
        ctx.fillStyle = c.isMembership ? '#00e676' : '#ffffff';
      }

      ctx.shadowColor   = 'rgba(0,0,0,0.9)';
      ctx.shadowBlur    = 4;
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 1;
      ctx.fillText(c.text, c.x, c.y);
      ctx.restore();
    }

    /* -- コメント追加 -- */
    addComment(msg) {
      if (this.comments.length >= this.maxComments) {
        const idx = this.comments.findIndex(c => !c.isSuperChat);
        if (idx !== -1) this.comments.splice(idx, 1);
        else return;
      }
      if (!this.canvas || !this.ctx) return;

      const fs   = msg.isSuperChat ? this.fontSize * 1.35 : this.fontSize;
      
      let text = '';
      const scPrefix = msg.isSuperChat && msg.superChatAmount ? `[${msg.superChatAmount}] ` : '';
      if (this.showUsername) {
        text = msg.isSuperChat ? `${scPrefix}${msg.author}: ${msg.text}` : `${msg.author}: ${msg.text}`;
      } else {
        text = msg.isSuperChat ? `${scPrefix}${msg.text}` : msg.text;
      }

      this.ctx.save();
      this.ctx.font = `bold ${fs}px "Noto Sans JP",Arial,sans-serif`;
      const w = this.ctx.measureText(text).width + 12;
      this.ctx.restore();

      // 文字が長い場合は最大で約+2だけ速度を速くする
      const speedBonus = Math.min(2.5, (w / this.canvas.width) * 2.5);
      const speed = this.baseSpeed + speedBonus;

      // 行（レーン）を取得してY座標を決定
      const lane = this.pickLane(fs, this.canvas.width, this.canvas.height, speed);

      this.comments.push({
        text, x: this.canvas.width + 10, y: lane.y,
        width: w, fontSize: fs, speed, lane: lane.id,
        isSuperChat:     msg.isSuperChat    || false,
        isMembership:    msg.isMembership   || false,
        superChatAmount: msg.superChatAmount || '',
        superChatColor:  msg.superChatColor  || '#f9a825',
      });
    }

    /**
     * 空きレーン（行）を探す。
     * 速度が違うコメントが追突しないか（画面外に出る前に追いつかないか）を計算して空きを判定。
     */
    pickLane(fontSize, canvasW, canvasH, newSpeed) {
      const lh = Math.ceil(fontSize + 6);
      const maxLane = Math.max(1, Math.floor(canvasH / lh));
      
      const lastInLane = new Map();
      for (const c of this.comments) {
        if (!lastInLane.has(c.lane) || c.x > lastInLane.get(c.lane).x) {
          lastInLane.set(c.lane, c);
        }
      }

      const availableLanes = [];
      for (let i = 0; i < maxLane; i++) {
        const lastC = lastInLane.get(i);
        
        if (!lastC) {
          availableLanes.push(i);
          continue;
        }

        // 1. まず初期ギャップがあるか（前のコメントの右端が画面内に十分入っているか）
        if (lastC.x + lastC.width + 20 >= canvasW) {
          continue;
        }

        // 2. 追突判定：新しいコメントが速い場合、前のコメントが消える前に追いつかないか？
        // 前のコメントの右端が完全に画面外(x=0)に消えるまでのフレーム数
        const framesToExit = (lastC.x + lastC.width) / lastC.speed;
        
        // そのフレーム数経過後の、新しいコメントの左端のX座標
        const newXAfterExit = canvasW - (newSpeed * framesToExit);

        // 新しいコメントの左端が 20px 以上の余裕を持って入ればセーフ（追突しない）
        if (newXAfterExit > 20) {
          availableLanes.push(i);
        }
      }

      let chosenLane;
      if (availableLanes.length > 0) {
        // 空いている行の中からランダムに選ぶ（まんべんなく散らすため）
        chosenLane = availableLanes[Math.floor(Math.random() * availableLanes.length)];
      } else {
        // 全部の行が詰まっている場合はランダムな行に重ねる
        chosenLane = Math.floor(Math.random() * maxLane);
      }

      return {
        id: chosenLane,
        y: chosenLane * lh + 6
      };
    }

    /* ==============================================
     * Document PiP API
     *
     * ビデオ要素を移動しないためYouTubeが壊れない。
     * PiP Canvas に毎フレーム drawImage でミラーするだけ。
     *
     * サイズ: 動画解像度の 50%（アスペクト比維持）
     * 表示:  Flexbox + max-width/height:100%;width/height:auto
     *        -> ウィンドウを変形しても引き延ばされずレターボックス表示
     * ============================================== */
    async enableDocumentPiP() {
      if (this.pipWin) return;

      if (!window.documentPictureInPicture) {
        console.warn('[NicoOverlay] Document PiP API 非対応 (Chrome 116+ 必要)');
        return;
      }

      const video = document.querySelector('#movie_player video');
      if (!video) return;

      try {
        // 動画の実解像度の 50% でウィンドウを開く（一回り小さく）
        const vW = video.videoWidth  || this.canvas?.width  || 854;
        const vH = video.videoHeight || this.canvas?.height || 480;
        const W  = Math.round(vW * 0.50);
        const H  = Math.round(vH * 0.50);

        const pipWin = await window.documentPictureInPicture.requestWindow({ width: W, height: H });
        this.pipWin   = pipWin;
        this.pipVideo = video;

        const doc = pipWin.document;
        doc.title = 'ニコニコオーバーレイ';

        // Flexbox で Canvas を中央配置 → 引き延ばさずレターボックス
        doc.body.style.cssText = [
          'margin:0', 'padding:0', 'background:#000',
          'display:flex', 'justify-content:center', 'align-items:center',
          'width:100vw', 'height:100vh', 'overflow:hidden',
        ].join(';');

        // Canvas はメインと同じ論理サイズ（座標系を統一）
        // CSS で max-width/height 制限し aspect-ratio を自動維持
        const pipCanvas = doc.createElement('canvas');
        pipCanvas.width  = this.canvas?.width  || 854;
        pipCanvas.height = this.canvas?.height || 480;
        pipCanvas.style.cssText = [
          'display:block',
          'max-width:100%', 'max-height:100%',
          'width:auto',     'height:auto',
        ].join(';');
        doc.body.appendChild(pipCanvas);

        this.pipCanvas = pipCanvas;
        this.pipCtx    = pipCanvas.getContext('2d');

        pipWin.addEventListener('pagehide', () => this.disableDocumentPiP());

      } catch (e) {
        console.error('[NicoOverlay] Document PiP error:', e);
        this.pipWin = this.pipVideo = null;
      }
    }

    /* PiP終了後始末（ビデオは動かしていないので YouTube は無傷） */
    disableDocumentPiP() {
      this.pipWin = this.pipCanvas = this.pipCtx = this.pipVideo = null;
    }

    applySettings(s) {
      if (s.maxComments != null) this.maxComments = s.maxComments;
      if (s.speed       != null) this.baseSpeed   = s.speed;
      if (s.fontSize    != null) this.fontSize    = s.fontSize;
      if (s.opacity     != null) this.opacity     = s.opacity;
      if (s.showUsername!= null) this.showUsername= s.showUsername;
    }

    destroy() {
      if (this.raf) cancelAnimationFrame(this.raf);
      this.resizeObs?.disconnect();
      this.overlayEl?.remove();
      this.disableDocumentPiP();
    }
  }

  /* -- ユーティリティ -- */
  function waitForElement(sel, cb, ms = 300, limit = 30000) {
    const el = document.querySelector(sel);
    if (el) { cb(el); return; }
    const t0 = Date.now();
    const tid = setInterval(() => {
      const f = document.querySelector(sel);
      if (f) { clearInterval(tid); cb(f); }
      else if (Date.now() - t0 > limit) clearInterval(tid);
    }, ms);
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) { ctx.roundRect(x, y, w, h, r); return; }
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y,   x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

})();
