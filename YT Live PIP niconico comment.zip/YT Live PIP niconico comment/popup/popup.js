/**
 * popup.js — ポップアップコントローラー
 *
 * 役割:
 *  • chrome.storage.sync から設定を読み込んでUIに反映
 *  • スライダー操作中にリアルタイムで数値ラベルを更新
 *  • 「設定を適用」でストレージ保存 + アクティブタブへ即時反映
 */

'use strict';

const toggleEnabled    = document.getElementById('toggleEnabled');
const speedRange       = document.getElementById('speedRange');
const fontSizeRange    = document.getElementById('fontSizeRange');
const opacityRange     = document.getElementById('opacityRange');
const maxCommentsRange = document.getElementById('maxCommentsRange');
const toggleSuperChat  = document.getElementById('toggleSuperChat');
const toggleMembership = document.getElementById('toggleMembership');
const toggleUsername   = document.getElementById('toggleUsername');
const settingsPanel    = document.getElementById('settingsPanel');
const pipBtn           = document.getElementById('pipBtn');
const pipHint          = document.getElementById('pipHint');

const speedValue       = document.getElementById('speedValue');
const fontSizeValue    = document.getElementById('fontSizeValue');
const opacityValue     = document.getElementById('opacityValue');
const maxCommentsValue = document.getElementById('maxCommentsValue');

const DEFAULTS = {
  enabled: true, speed: 8, fontSize: 26, opacity: 0.9,
  maxComments: 40, showSuperChat: true, showMembership: true, showUsername: true,
};

/* ── 起動時：保存済み設定を読み込む ── */
chrome.storage.sync.get(DEFAULTS, (s) => {
  toggleEnabled.checked    = s.enabled;
  speedRange.value         = s.speed;
  fontSizeRange.value      = s.fontSize;
  opacityRange.value       = Math.round(s.opacity * 100);
  maxCommentsRange.value   = s.maxComments;
  toggleSuperChat.checked  = s.showSuperChat;
  toggleMembership.checked = s.showMembership;
  toggleUsername.checked   = s.showUsername;
  refreshLabels(s);
  setPanelState(s.enabled);
});

/* ══════════════════════════════════════════
 * PiP起動ボタン
 * ══════════════════════════════════════════ */
pipBtn.addEventListener('click', async () => {
  pipBtn.disabled = true;
  setPipHint('', '');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.url?.includes('youtube.com/watch')) {
      setPipHint('✖ YouTube Liveの動画ページで開いてください', 'error');
      return;
    }

    // ユーザージェスチャーを保持したままタブ内で関数を実行
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'ISOLATED',
      func: () => {
        // content.jsのリスナーが受取るカスタムイベントを発火
        document.dispatchEvent(new CustomEvent('__yt_nicovideo_pip_request'));
      },
    });

    setPipHint('✓ PiPを起動しました', 'success');

    // ポップアップを自動で閉じる
    setTimeout(() => window.close(), 800);

  } catch (e) {
    console.error('[PiPボタン]', e);
    setPipHint(`✖ エラー: ${e.message}`, 'error');
  } finally {
    pipBtn.disabled = false;
  }
});

function setPipHint(msg, type) {
  pipHint.textContent = msg;
  pipHint.className = 'pip-hint' + (type ? ` ${type}` : '');
}

/* ── スライダー操作中のリアルタイム表示 ── */
speedRange.addEventListener('input',       () => { speedValue.textContent       = speedRange.value; });
fontSizeRange.addEventListener('input',    () => { fontSizeValue.textContent    = fontSizeRange.value; });
opacityRange.addEventListener('input',     () => { opacityValue.textContent     = opacityRange.value; });
maxCommentsRange.addEventListener('input', () => { maxCommentsValue.textContent = maxCommentsRange.value; });

/* ── マスタートグル ── */
toggleEnabled.addEventListener('change', () => {
  setPanelState(toggleEnabled.checked);
  autoSave();
});

/* ── 各種設定のオートセーブ ── */
const inputs = [speedRange, fontSizeRange, opacityRange, maxCommentsRange, toggleSuperChat, toggleMembership, toggleUsername];
inputs.forEach(input => {
  input.addEventListener('change', autoSave);
  if (input.type === 'range') {
    input.addEventListener('input', autoSave);
  }
});

async function autoSave() {
  const s = readForm();
  await chrome.storage.sync.set(s);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id && tab.url?.includes('youtube.com')) {
      await chrome.tabs.sendMessage(tab.id, { type: 'SETTINGS_UPDATE', settings: s });
    }
  } catch (_) {}
}

/* ── ヘルパー関数 ── */
function readForm() {
  return {
    enabled:        toggleEnabled.checked,
    speed:          Number(speedRange.value),
    fontSize:       Number(fontSizeRange.value),
    opacity:        Number(opacityRange.value) / 100,
    maxComments:    Number(maxCommentsRange.value),
    showSuperChat:  toggleSuperChat.checked,
    showMembership: toggleMembership.checked,
    showUsername:   toggleUsername.checked,
  };
}

function refreshLabels(s) {
  speedValue.textContent       = s.speed;
  fontSizeValue.textContent    = s.fontSize;
  opacityValue.textContent     = Math.round(s.opacity * 100);
  maxCommentsValue.textContent = s.maxComments;
}

function setPanelState(enabled) {
  settingsPanel.classList.toggle('disabled', !enabled);
}
